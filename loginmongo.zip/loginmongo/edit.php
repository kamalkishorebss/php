<?php
	include 'connection.php'; 
	$id = $_GET['id'];
	//echo $id;
	$query = array('_id' => new MongoId($id));
	//print_r($query);
	$cursor = $collection->findOne(array('_id' => new MongoId(new MongoId($id))));
    //print_r($cursor);
	?>

	<html>
      <center><body bgcolor="lightBlue">
        <h1 style="background-color:green;">User Info</h1>
        <form action="edit_action.php" method="POST" name="myForm">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
	    <b>FirstName:-</b><input type="text" name="fname" value="<?php echo $cursor["First Name"]; ?>"><br></br>
	    <b>LastName:-</b><input type="text"  name="lname" value="<?php echo $cursor["Last Name"]; ?>"><br></br>
	    <b>EmailAdds:-</b><input type="email" name="email" value="<?php echo $cursor["Email Address"]; ?>"><br></br>

	    <input type="submit" name="sub">
        </form>
         </body>
       </center>
    </html>
