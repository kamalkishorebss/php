<?php
    require_once 'library.php';
    if(chkLogin()){
       ?>
        <span style="color:green;">Logged in!</span>
        <?php
        $name = $_SESSION["uname"];
        echo "Welcome $name!!!";
        ?>
<?php        
    }
    else{
        header("Location: login.php");
    }

    if(isset($_POST['logout'])){ 

        
        $var = removeall();
        if($var){
            header("Location:login.php");
        }
        else{
            echo "Error!";
        }
    
    }


?>
<html>
<head>
<link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
</head>
    <body>

    <h1 align="center" style="color:red">Welcome To The Home Page</h1>
        <form method="post" action="">
            <input type="button" class="btn btn-danger" name="userdetail" value="show Users" onclick="red()" style="margin-left:500px;">
            <input type="submit" class="btn btn-danger" name="logout" value="Logout!" style="margin-left:500px;">
            
        </form>
        <script>
        function red()
        {
           return window.location.assign("userdetail.php") 
        }
        </script>
   </body>
</html>