<?php
	include 'connection.php'; 
	$id = $_GET['id'];
	//echo $id;
	$query = array('_id' => new MongoId($id));
	//print_r($query);
	$cursor = $collection->findOne(array('_id' => new MongoId(new MongoId($id))));
	//print_r($cursor);
      // for each($cursor as $value)
      // {
      // 	echo $value["First Name"];
      // }
   
  
//echo "First Name".$cursor["First Name"];
// if($cursor){
//	header('Location : ');	
//} 
?>
<html>
<center><body bgcolor="lightBlue">
<h1 style="background-color:green;">User Info</h1>
	<big><b>FirstName:-</b></big><?php echo $cursor["First Name"]; ?><br></br>
	<big><b>LastName:-</b></big><?php echo $cursor["Last Name"]; ?><br></br>
	<big><b>Email:-</b></big><?php echo $cursor["Email Address"]; ?><br></br>

</body>
</center>
</html>