<?php
	include 'connection.php'; 
	 $id = $_GET['id'];
	 
	$remove = $collection->remove(array("_id" => new MongoId($id)));
          
			if($remove){
                header('Location: userdetail.php');
 			}
       			
    //print_r($cursor);
	?>