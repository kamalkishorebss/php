<?php
    require_once 'library.php';
    if(chkLogin()){
        header("Location: home.php");
    }
?>
<html>
    <head>
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
    </head>
    <body>

    <div class="container" style="margin-top:100px">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Please sign in</h3>
                </div>
                <div class="panel-body">
                    <form accept-charset="UTF-8" role="form" method="post" action="login_action.php">
                    <fieldset>
                        <div class="form-group">
                            <input type="email" class="form-control" id="exampleInputEmail3" name="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" id="exampleInputPassword3" name="pass" placeholder="Password" required>
                        </div>
                        
                        <input class="btn btn-lg btn-success btn-block" type="submit" name="login" value="Login">
                       
                    </fieldset>

                    <p  style="color:lightBlue; margin-top:10px; margin-left:150px;"><a href="register.php">New User Register First</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
        <!-- <div class="container">
            <form class="form-horizontal" method="post" action="login_action.php">
                <div class="form-group">
                    <label class="sr-only" for="exampleInputEmail3">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail3" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label class="sr-only" for="exampleInputPassword3">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword3" name="pass" placeholder="Password" required>
                </div>
                <button type="submit" name="login" class="btn btn-default">Sign in</button>
            </form>
        </div> -->
    </body>
</html>