<?php 
//session_start();
include 'connection.php'; 
 ?>
      <h1 align=center style="background-color:green;">All User Detail</h1>
<center>


    <table border="1">
     
      <tr><th>Sr</th><th>ID</th><th>First Name</th><th colspan='3'>Action</th></tr>
  <?php
  $cursor = $collection->find();
  $Sr =0;
  foreach ( $cursor as $key )
   {
    $Sr++;
?>

      <tr>
        <td><?php echo $Sr; ?></td>
        <td width=330><?php echo $key["_id"]; ?></td>
        <td width=150><?php echo $key["First Name"];?></td>
        <td><a href="view.php?id=<?php echo $key["_id"];?>" style='text-decoration:none;'>View</a></td>
        <td><a href="edit.php?id=<?php echo $key["_id"];?>" style='text-decoration:none;'>Edit</a></td>
        <td><a href="delete.php?id=<?php echo $key["_id"];?>" style='text-decoration:none;'>[X]</a></td>
      </tr>

   
  <?php
}
?>
 </table>
    </center>


