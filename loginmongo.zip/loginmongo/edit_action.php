<?php
include 'connection.php';
include 'edit.php';

?>

<?php
   if(isset($_POST['sub'])){
       
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $id    = $_POST['id'];
        // $temp  = $_POST['pass'];
        // $options = array('cost' => 10);
        // $pass = password_hash($temp, PASSWORD_BCRYPT, $options);
    
        $arrays = array(
            
            "First Name"    => $fname,
            "Last Name"     => $lname,
            "Email Address" => $email
        );
         
         $update = $collection->update(array("_id" => new MongoId($id) ), 
       								   array('$set'=>$arrays));
   
   if($update){
   	header('Location: userdetail.php');
   }
}
?>