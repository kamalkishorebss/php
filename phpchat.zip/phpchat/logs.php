<?php 
 
$servername = "localhost";
$username = "root";
$password = "root";

$database = "test";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database);

		
$result1 = "SELECT * FROM logs ORDER by id DESC";

$fetchsucessfully = mysqli_query($conn,$result1);

   while($extract = mysqli_fetch_array($fetchsucessfully))
    {
      echo "<span class ='uname'>" .$extract['username']."</span>&nbsp:&nbsp<span class='msg'>" .$extract['msg']."</span><br><br/>";
    }
?>