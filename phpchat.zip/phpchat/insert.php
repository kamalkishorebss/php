<?php 
 

$uname = $_REQUEST['uname'];
$msg = $_REQUEST['msg'];


$servername = "localhost";
$username = "root";
$password = "root";

$database = "test";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database);

// Check connection
/*if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
   echo "Connected successfully";
*/

	$insertData = "INSERT INTO logs (username,msg) VALUES ('$uname','$msg')";


	$insertsucessfully = mysqli_query($conn,$insertData);

	/*if($insertsucessfully)
	{

		
		echo "data successfully inserted";



	}
	else{


			echo "data not successfully inserted";


	}


*/
		


$result1 = "SELECT * FROM logs ORDER by id DESC";

$fetchsucessfully = mysqli_query($conn,$result1);

   while($extract = mysqli_fetch_array($fetchsucessfully))
    {
      echo "<span class ='uname'>" .$extract['username']."</span>:<span class='msg'>" .$extract['msg']."</span><br>";
    }
?>