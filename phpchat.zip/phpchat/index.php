<?php


?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"  />
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script>
function submitChat()
{
     	if(form1.uname.value == '' || form1.msg.value == '')
        	{
		      alert('All filedes are mandatory!!');
		      return;
	        }
	
	    form1.uname.readyOnly = true;
	    form1.uname.style.border='none';
	    var uname = form1.uname.value;
	    var msg = form1.msg.value;
            uname = "";
            msg = "";
	    /*alert(uname);
	    alert(msg); */


	    var xmlhttp =new XMLHttpRequest();
	
	    xmlhttp.onreadystatechange=function()
            {
               if(xmlhttp.readyState==4 && xmlhttp.status==200)
                  {
                    document.getElementById("chatlogs").innerHTML=xmlhttp.responseText;
                  }

			}
            xmlhttp.open("GET",'insert.php?uname='+uname+ '&msg=' + msg, true);
			xmlhttp.send();


    

}

//jquery for auto load page after 2second 
$(document).ready(function(e)
	{
      $.ajaxSetup({cache:false});
      setInterval(function()
	    {
		  $("#chatlogs").load("logs.php");
		},2000); 
	});	
		
</script>
</head>
<body>
<h1 align="center">CHAT BOX</h1>
<form name="form1" id="myform">
	Enter Your Chatname: <input type="text" name="uname" style="width:200px;"/><br/>
    <div id="chatlogs">
    Loading Chatlogs Please wait...
    </div>
	 <br/>
	<textarea name="msg" style="width:200px; height:30px;" placeholder="Your Message.."></textarea />
	<a href="#" onclick="submitChat()">Send</a><br /><br />
</form>
<h1 align="center">CHAT BOX</h1>
</body>